const AuthService = require('./auth.services')

module.exports = class UserService{

}